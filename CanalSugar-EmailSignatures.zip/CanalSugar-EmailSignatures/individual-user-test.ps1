Import-Module ExchangeOnlineManagement -Force

$adminEmail = "your-admin@canalsugar.com"
$templatePath = ".\CanalSugar_Simple_Template.html"
$testUser = "mohamed.hamido@canalsugar.com"  # Replace with actual test user

Connect-ExchangeOnline -UserPrincipalName $adminEmail

$template = Get-Content $templatePath -Raw -Encoding UTF8
$userDetails = Get-EXORecipient -Identity $testUser

$signature = $template
$signature = $signature -replace '%%DisplayName%%', $userDetails.DisplayName
$signature = $signature -replace '%%Title%%', $userDetails.Title
$signature = $signature -replace '%%Department%%', $userDetails.Department
$signature = $signature -replace '%%Company%%', 'Canal Sugar'
$signature = $signature -replace '%%PhoneNumber%%', $userDetails.Phone
$signature = $signature -replace '%%MobileNumber%%', $userDetails.MobilePhone
$signature = $signature -replace '%%UserPrincipalName%%', $userDetails.UserPrincipalName

Set-MailboxMessageConfiguration -Identity $testUser -SignatureHtml $signature -AutoAddSignature $true

Write-Host "Test signature applied to: $testUser"
Write-Host "Generated signature preview:"
Write-Host $signature

Disconnect-ExchangeOnline -Confirm:$false