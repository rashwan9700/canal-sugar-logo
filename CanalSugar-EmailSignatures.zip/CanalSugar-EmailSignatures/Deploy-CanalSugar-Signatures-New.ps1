<#
.SYNOPSIS
    Canal Sugar Simple Email Signature Deployment Script
    
.DESCRIPTION
    This script deploys the minimalist email signature template that follows the 
    Bahy Mohamed example format with clean, simple layout and Canal Sugar branding.
    
.AUTHOR
    Canal Sugar IT Department
    
.VERSION
    2.0 - Updated for Simple Template
#>

# Import required modules
Import-Module ExchangeOnlineManagement -Force

# Configuration Variables
$adminEmail = "admin@canalsugar.com"  # Replace with your actual admin email
$templatePath = ".\CanalSugar_Simple_Template.html"
$logFile = ".\CanalSugar_Simple_Deployment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# Create log directory if it doesn't exist
$logDir = Split-Path $logFile -Parent
if (-not (Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir -Force
}

# Function to write detailed log entries
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO", "SUCCESS", "WARNING", "ERROR")]
        [string]$Level = "INFO"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    
    # Color coding for console output
    switch ($Level) {
        "SUCCESS" { Write-Host $logEntry -ForegroundColor Green }
        "WARNING" { Write-Host $logEntry -ForegroundColor Yellow }
        "ERROR"   { Write-Host $logEntry -ForegroundColor Red }
        default   { Write-Host $logEntry -ForegroundColor White }
    }
    
    # Write to log file
    Add-Content -Path $logFile -Value $logEntry
}

# Function to validate user data
function Test-UserData {
    param($UserDetails)
    
    $missingFields = @()
    
    if ([string]::IsNullOrEmpty($UserDetails.DisplayName)) { 
        $missingFields += "DisplayName" 
    }
    if ([string]::IsNullOrEmpty($UserDetails.PrimarySmtpAddress)) { 
        $missingFields += "Email" 
    }
    
    return $missingFields
}

# Function to format phone numbers consistently
function Format-PhoneNumber {
    param([string]$PhoneNumber)
    
    if ([string]::IsNullOrEmpty($PhoneNumber)) {
        return ""
    }
    
    # Remove any existing formatting
    $cleanNumber = $PhoneNumber -replace '[^\d+]', ''
    
    # Add Egypt country code if not present and format
    if ($cleanNumber -match '^\d{11}$') {
        $cleanNumber = "+20 " + $cleanNumber.Substring(1)
    }
    elseif ($cleanNumber -match '^\+20\d{10}$') {
        $cleanNumber = $cleanNumber.Insert(3, " ")
    }
    
    return $cleanNumber
}

try {
    Write-Log "======================================================="
    Write-Log "Starting Canal Sugar Simple Email Signature Deployment"
    Write-Log "======================================================="
    Write-Log "Script Version: 2.0"
    Write-Log "Template: Simple Format (Bahy Mohamed Style)"
    Write-Log "Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    
    # Validate prerequisites
    Write-Log "Checking prerequisites..."
    
    # Check if template file exists
    if (-not (Test-Path $templatePath)) {
        throw "Template file not found at: $templatePath. Please ensure the HTML template file is in the correct location."
    }
    Write-Log "✓ Template file found: $templatePath"
    
    # Load and validate the signature template
    try {
        $template = Get-Content $templatePath -Raw -Encoding UTF8
        if ([string]::IsNullOrEmpty($template)) {
            throw "Template file is empty or corrupted"
        }
        Write-Log "✓ Simple Canal Sugar template loaded successfully ($(($template.Length/1024).ToString('F2')) KB)"
    }
    catch {
        throw "Failed to load template file: $($_.Exception.Message)"
    }
    
    # Connect to Exchange Online
    Write-Log "Attempting to connect to Exchange Online..."
    try {
        Connect-ExchangeOnline -UserPrincipalName $adminEmail -ShowProgress $true -ErrorAction Stop
        Write-Log "✓ Successfully connected to Exchange Online" "SUCCESS"
    }
    catch {
        throw "Failed to connect to Exchange Online: $($_.Exception.Message)"
    }
    
    # Get organizational information
    try {
        $orgConfig = Get-OrganizationConfig
        Write-Log "Connected to organization: $($orgConfig.DisplayName)"
    }
    catch {
        Write-Log "Could not retrieve organization details" "WARNING"
    }
    
    # Get all active users
    Write-Log "Retrieving Canal Sugar employee list..."
    try {
        $users = Get-EXOMailbox -RecipientTypeDetails UserMailbox -ResultSize Unlimited | 
                 Where-Object { $_.AccountDisabled -eq $false -and $_.ExchangeUserAccountControl -notlike "*AccountDisabled*" }
        
        if ($users.Count -eq 0) {
            throw "No active users found in the organization"
        }
        
        Write-Log "Found $($users.Count) active users to process"
    }
    catch {
        throw "Failed to retrieve user list: $($_.Exception.Message)"
    }
    
    # Initialize counters
    $successCount = 0
    $errorCount = 0
    $skippedCount = 0
    
    Write-Log "Beginning signature deployment process..."
    Write-Log "---------------------------------------"
    
    foreach ($user in $users) {
        try {
            Write-Log "Processing: $($user.UserPrincipalName)"
            
            # Get detailed user information
            try {
                $userDetails = Get-EXORecipient -Identity $user.UserPrincipalName -ErrorAction Stop
            }
            catch {
                Write-Log "Failed to get user details for $($user.UserPrincipalName): $($_.Exception.Message)" "ERROR"
                $errorCount++
                continue
            }
            
            # Validate required data
            $missingFields = Test-UserData -UserDetails $userDetails
            if ($missingFields.Count -gt 0) {
                Write-Log "Skipping $($user.UserPrincipalName) - Missing required fields: $($missingFields -join ', ')" "WARNING"
                $skippedCount++
                continue
            }
            
            # Create personalized signature for simple template
            $signature = $template
            
            # Replace placeholders with actual data
            $signature = $signature -replace '%%DisplayName%%', ($userDetails.DisplayName ?? "")
            $signature = $signature -replace '%%Title%%', ($userDetails.Title ?? "")
            $signature = $signature -replace '%%PhoneNumber%%', (Format-PhoneNumber -PhoneNumber ($userDetails.Phone ?? ""))
            $signature = $signature -replace '%%UserPrincipalName%%', ($userDetails.PrimarySmtpAddress ?? "")
            
            # Apply signature to user's mailbox
            try {
                Set-MailboxMessageConfiguration -Identity $user.UserPrincipalName -SignatureHtml $signature -AutoAddSignature $true -ErrorAction Stop
                Write-Log "✓ Simple signature successfully applied for: $($user.UserPrincipalName)" "SUCCESS"
                $successCount++
            }
            catch {
                Write-Log "Failed to apply signature for $($user.UserPrincipalName): $($_.Exception.Message)" "ERROR"
                $errorCount++
            }
            
        }
        catch {
            Write-Log "Unexpected error processing user $($user.UserPrincipalName): $($_.Exception.Message)" "ERROR"
            $errorCount++
        }
    }
    
    # Final summary
    Write-Log "======================================================="
    Write-Log "CANAL SUGAR SIMPLE SIGNATURE DEPLOYMENT COMPLETED"
    Write-Log "======================================================="
    Write-Log "Total users found: $($users.Count)"
    Write-Log "Successful deployments: $successCount" "SUCCESS"
    Write-Log "Errors encountered: $errorCount" $(if ($errorCount -gt 0) { "ERROR" } else { "INFO" })
    Write-Log "Users skipped (missing data): $skippedCount" $(if ($skippedCount -gt 0) { "WARNING" } else { "INFO" })
    Write-Log "Success rate: $(if ($users.Count -gt 0) { [math]::Round(($successCount / $users.Count) * 100, 2) } else { 0 })%"
    Write-Log "Log file saved to: $logFile"
    Write-Log "======================================================="
    
    # Display next steps
    if ($successCount -gt 0) {
        Write-Log ""
        Write-Log "NEXT STEPS:" "INFO"
        Write-Log "1. Test signatures by having users compose new emails in Outlook Web App"
        Write-Log "2. Verify signatures appear correctly across different email clients"
        Write-Log "3. Check that the Canal Sugar logo and GIF display properly"
        Write-Log "4. For any users with errors, verify their profile data in Microsoft 365 Admin Center"
    }
    
}
catch {
    Write-Log "Script execution failed: $($_.Exception.Message)" "ERROR"
    Write-Log "Please check the error details above and retry" "ERROR"
    exit 1
}
finally {
    # Clean up connection
    Write-Log "Cleaning up Exchange Online connection..."
    try {
        Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue
        Write-Log "✓ Disconnected from Exchange Online"
    }
    catch {
        Write-Log "Note: Connection cleanup completed" "WARNING"
    }
    
    Write-Log "Canal Sugar simple signature deployment script completed"
    Write-Log "Script execution time: $((Get-Date) - $scriptStartTime)" -ErrorAction SilentlyContinue
}

# Add script start time tracking
$scriptStartTime = Get-Date
