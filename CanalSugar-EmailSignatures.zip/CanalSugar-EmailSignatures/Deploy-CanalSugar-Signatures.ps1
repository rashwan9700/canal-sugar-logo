<#
.SYNOPSIS
    Canal Sugar Email Signature Deployment Script - Updated with icons and white text
#>

# Import required modules
Import-Module ExchangeOnlineManagement -Force

# Configuration
$adminEmail = "admin@canalsugar.com"  # Replace with your admin email
$templatePath = ".\CanalSugar_Updated_Template.html"
$logFile = ".\CanalSugar_Deployment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# Function to write log entries
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    Write-Host $logEntry
    Add-Content -Path $logFile -Value $logEntry
}

try {
    Write-Log "Starting Canal Sugar Email Signature Deployment (Updated Template)"
    
    # Check if template file exists
    if (-not (Test-Path $templatePath)) {
        throw "Template file not found at: $templatePath"
    }
    
    # Load the signature template
    $template = Get-Content $templatePath -Raw -Encoding UTF8
    Write-Log "Updated Canal Sugar template loaded successfully"
    
    # Connect to Exchange Online
    Write-Log "Connecting to Exchange Online..."
    Connect-ExchangeOnline -UserPrincipalName $adminEmail -ShowProgress $true
    Write-Log "Successfully connected to Exchange Online"
    
    # Get all active users
    Write-Log "Retrieving Canal Sugar user list..."
    $users = Get-EXOMailbox -RecipientTypeDetails UserMailbox -ResultSize Unlimited | Where-Object {$_.AccountDisabled -eq $false}
    Write-Log "Found $($users.Count) active users"
    
    $successCount = 0
    $errorCount = 0
    
    foreach ($user in $users) {
        try {
            Write-Log "Processing user: $($user.UserPrincipalName)"
            
            # Get detailed user information
            $userDetails = Get-EXORecipient -Identity $user.UserPrincipalName
            
            # Create personalized signature with NEW FIELDS
            $signature = $template
            $signature = $signature -replace '%%DisplayName%%', ($userDetails.DisplayName ?? "")
            $signature = $signature -replace '%%Title%%', ($userDetails.Title ?? "")
            $signature = $signature -replace '%%Department%%', ($userDetails.Department ?? "")
            $signature = $signature -replace '%%PhoneNumber%%', ($userDetails.Phone ?? "")
            $signature = $signature -replace '%%MobileNumber%%', ($userDetails.MobilePhone ?? "")
            $signature = $signature -replace '%%FaxNumber%%', ($userDetails.Fax ?? "")  # NEW: Fax field
            $signature = $signature -replace '%%UserPrincipalName%%', ($userDetails.UserPrincipalName ?? "")
            
            # Apply signature to user's mailbox
            Set-MailboxMessageConfiguration -Identity $user.UserPrincipalName -SignatureHtml $signature -AutoAddSignature $true
            
            Write-Log "✓ Updated Canal Sugar signature applied for: $($user.UserPrincipalName)" "SUCCESS"
            $successCount++
            
        }
        catch {
            Write-Log "✗ Error processing user $($user.UserPrincipalName): $($_.Exception.Message)" "ERROR"
            $errorCount++
        }
    }
    
    # Summary
    Write-Log "=== CANAL SUGAR UPDATED DEPLOYMENT SUMMARY ==="
    Write-Log "Total users processed: $($users.Count)"
    Write-Log "Successful deployments: $successCount"
    Write-Log "Errors encountered: $errorCount"
    Write-Log "Log file saved to: $logFile"
    
}
catch {
    Write-Log "Script execution failed: $($_.Exception.Message)" "ERROR"
}
finally {
    # Clean up connection
    Write-Log "Disconnecting from Exchange Online..."
    Disconnect-ExchangeOnline -Confirm:$false
    Write-Log "Canal Sugar signature deployment completed"
}
